<?php

require("conexion.php");

if(isset($_POST['btn'])) {

    if ($_POST['documento']!="" && $_POST['contrasena']!="") {

        $documento = $_POST['documento'];
        $contrasena = $_POST['contrasena'];

        $sql="SELECT contrasena FROM usuario WHERE documento='$documento'";

        $consulta = $con->query($sql);        		
        $arreglo = mysqli_num_rows ($consulta);

        $data = mysqli_fetch_assoc($consulta);
        $hash = implode($data);

        if ($arreglo > 0) {

            echo '<script>
            location.href = "../dashboard.html";
            </script>';

        } else {
            echo '<script>
            alert("Usuario no encontrado");
            window.history.go(-1);
            </script>';
    exit;
        }
    }
}

?>